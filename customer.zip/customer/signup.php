<?php






?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SignUp Customer</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>

</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!--  navigation -->
              <?php require_once "navi.php" ?>
        </div>
        <div class="row">
            <div class="col-md-8 mx-auto py-5">
                    <form action="" class="form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="email" class="form-label">email</label>
                                        <input type="email" class="form-control" name="email" id="email" 
                                        required placeholder="abc@gmail.com">
                                    </div>
                                    <div class="mb-3">
                                        <label for="fullname" class="form-label">Fullname</label>
                                        <input type="text" class="form-control" name="fullname" id="fullname"
                                        required >
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Password</label>
                                        <input type="password" class="form-control" name="password" id="password"
                                        required >
                                    </div>
                                    <div class="mb-3">
                                        <label for="cpassword" class="form-label">Confirm Password</label>
                                        <input type="password" class="form-control" name="cpassword" id="cpassword"
                                        required >
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label for="bdate" class="form-label">Birth Date</label>
                                        <input type="date" class="form-control" name="bdate" id="bdate">
                                    </div>
                                    <p>Choose Gender</p>
                                    <div class="form-check mb-1">                                        
                                        <input type="radio" class="form-check-input" name="gender" id="gender">
                                        <label for="gender" class="form-check-label">Male</label>
                                    </div>
                                     <div class="form-check mb-3">                                        
                                        <input type="radio" class="form-check-input" name="gender" id="gender">
                                        <label for="gender" class="form-check-label">Female</label>
                                    </div>
                                    <div class="mb-3">
                                        <label for="" class="form-label">Choose City</label>
                                        <select name="city" id="city" class="form-select">
                                            <option value="mdy">Mandalay</option>
                                             <option value="ygn">Yangon</option>
                                              <option value="tgi">Taunggyi</option>
                                               <option value="mlm">Mawlamyaing</option>
                                               <option value="stw">Sittway</option>
                                                <option value="mgy">Magway</option>
                                        </select>
                                    </div>
                                    <button class="btn btn-primary" type="submit" name="signUp">Sign Up</button>

                                </div>

                            </div>




                    </form>
            </div>
        </div>








    </div>

    
</body>
</html>